# AmsiHook
AmsiHook is a DLL that when injected to a process containing AMSI logging, will hook the AMSI functions and allow them to execute with dummy parameters.

## Notes
I wrote an injector that works with the tool. That can be found [here](https://github.com/tomcarver16/SimpleInjector)

Also to see how I developed this tool and my process behind creating it see my blog [post](https://x64sec.sh/understanding-and-bypassing-amsi/)
