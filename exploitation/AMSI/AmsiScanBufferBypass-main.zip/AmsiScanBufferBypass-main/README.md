# AmsiScanBufferBypass
Bypass AMSI by patching AmsiScanBuffer.

https://rastamouse.me/memory-patching-amsi-bypass/
