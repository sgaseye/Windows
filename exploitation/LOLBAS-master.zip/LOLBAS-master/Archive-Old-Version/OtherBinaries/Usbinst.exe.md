## Usbinst.exe
* Functions: Execute
```

Usbinst.exe InstallHinfSection "DefaultInstall 128 c:\temp\calc.inf"
Execute calc.exe through DefaultInstall Section Directive in INF file.
```
   
* Resources:   
  * https://twitter.com/pabraeken/status/993514357807108096
   
* Full path:   
  * C:\Program Files (x86)\Citrix\ICA Client\Drivers64\Usbinst.exe
   
* Notes: Thanks to Pierre-Alexandre Braeken - @pabraeken  
   
