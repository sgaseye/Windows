## ROCCAT_Swarm.exe
* Functions: Execute
```

Replace ROCCAT_Swarm_Monitor.exe with your binary.exe
Hijack ROCCAT_Swarm_Monitor.exe and launch payload when executing ROCCAT_Swarm.exe
```
   
* Resources:   
  * https://twitter.com/pabraeken/status/994213164484001793
   
* Full path:   
  * C:\Program Files (x86)\ROCCAT\ROCCAT Swarm\
   
* Notes: Thanks to Pierre-Alexandre Braeken - @pabraeken  
   
