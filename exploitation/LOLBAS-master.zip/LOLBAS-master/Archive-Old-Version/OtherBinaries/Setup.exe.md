## Setup.exe
* Functions: Execute
```

Run Setup.exe
Hijack hpbcsiServiceMarshaller.exe and run Setup.exe to launch a payload.
```
   
* Resources:   
  * https://twitter.com/pabraeken/status/994381620588236800
   
* Full path:   
  * C:\LJ-Ent-700-color-MFP-M775-Full-Solution-15315
   
* Notes: Thanks to Pierre-Alexandre Braeken - @pabraeken  
   
