## odbcconf.exe
* Functions: Execute
```

odbcconf -f file.rsp
Load DLL specified in target .RSP file.
```
   
* Resources:   
  * https://gist.github.com/NickTyrer/6ef02ce3fd623483137b45f65017352b
  * https://github.com/woanware/application-restriction-bypasses
  * https://twitter.com/subTee/status/789459826367606784
   
* Full path:   
  * c:\windows\system32\odbcconf.exe    
  * c:\windows\sysWOW64\odbcconf.exe
   
* Notes: Thanks to Casey Smith - @subtee, Nick Tyrer - @NickTyrer
See the Playloads folder for an example .RSP file.
  
   
