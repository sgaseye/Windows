## Ie4unit.exe
* Functions: Execute
```

ie4unit.exe -BaseSettings
Executes commands from a specially prepared ie4uinit.inf file.
```
   
* Resources:   
  * https://bohops.com/2018/03/10/leveraging-inf-sct-fetch-execute-techniques-for-bypass-evasion-persistence-part-2/
   
* Full path:   
  * c:\windows\system32\ie4unit.exe    
  * c:\windows\sysWOW64\ie4unit.exe    
  * c:\windows\system32\ieuinit.inf    
  * c:\windows\sysWOW64\ieuinit.inf    
   
* Notes: Thanks to Jimmy - @bohops  
   
