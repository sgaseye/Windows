## Openwith.exe
* Functions: Execute
```

OpenWith.exe /c C:\test.hta
Opens the target file with the default application.

OpenWith.exe /c C:\testing.msi
Opens the target file with the default application.
```
   
* Resources:   
  * https://twitter.com/harr0ey/status/991670870384021504
   
* Full path:   
  * c:\windows\system32\Openwith.exe
  * c:\windows\sysWOW64\Openwith.exe
   
* Notes: Thanks to Matt harr0ey - @harr0ey  
   
