## Wab.exe
* Functions: Execute
```

Wab.exe
Loads a DLL configured in the registry under HKLM.
```
   
* Resources:   
  * http://www.hexacorn.com/blog/2018/05/01/wab-exe-as-a-lolbin/
  * https://twitter.com/Hexacorn/status/991447379864932352
   
* Full path:   
  * C:\Program Files\Windows Mail\wab.exe    
  * C:\Program Files (x86)\Windows Mail\wab.exe    
   
* Notes: Thanks to Adam - @Hexacorn
Requires registry changes, Requires Administrative Access  
   
