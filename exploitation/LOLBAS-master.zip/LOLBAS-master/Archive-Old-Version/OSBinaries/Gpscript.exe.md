## Gpscript.exe
* Functions: Execute
```

Gpscript /logon
Executes logon scripts configured in Group Policy.

Gpscript /startup
Executes startup scripts configured in Group Policy.
```
   
* Resources:   
  * https://oddvar.moe/2018/04/27/gpscript-exe-another-lolbin-to-the-list/
   
* Full path:   
  * c:\windows\system32\gpscript.exe
  * c:\windows\sysWOW64\gpscript.exe
   
* Notes: Thanks to Oddvar Moe - @oddvarmoe
Requires administrative rights and modifications to local group policy settings.
  
   
