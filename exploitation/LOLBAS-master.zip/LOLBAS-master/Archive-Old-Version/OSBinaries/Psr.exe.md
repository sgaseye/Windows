## Psr.exe
* Functions: Surveillance
```

psr.exe /start /gui 0 /output c:\users\user\out.zip
Capture screenshots of the desktop and save them in the target .ZIP file.

psr.exe /start /maxsc 100 /gui 0 /output c:\users\user\out.zip
Capture a maximum of 100 screenshots of the desktop and save them in the target .ZIP file.

psr.exe /stop
Stop the Problem Step Recorder.
```
   
* Resources:   
  * https://www.sans.org/summit-archives/file/summit-archive-1493861893.pdf
   
* Full path:   
  * C:\Windows\System32\Psr.exe
  * C:\Windows\SysWOW64\Psr.exe
   
* Notes: Thanks to   
   
