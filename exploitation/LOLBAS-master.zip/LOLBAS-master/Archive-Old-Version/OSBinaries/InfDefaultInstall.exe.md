## InfDefaultInstall.exe
* Functions: Execute
```

InfDefaultInstall.exe Infdefaultinstall.inf
Executes SCT script using scrobj.dll from a command in entered into a specially prepared INF file.
```
   
* Resources:   
  * https://twitter.com/KyleHanslovan/status/911997635455852544
  * https://gist.github.com/KyleHanslovan/5e0f00d331984c1fb5be32c40f3b265a
  * https://blog.conscioushacker.io/index.php/2017/10/25/evading-microsofts-autoruns/
   
* Full path:   
  * c:\windows\system32\Infdefaultinstall.exe
  * c:\windows\sysWOW64\Infdefaultinstall.exe
   
* Notes: Thanks to Kyle Hanslovan - @kylehanslovan  
   
