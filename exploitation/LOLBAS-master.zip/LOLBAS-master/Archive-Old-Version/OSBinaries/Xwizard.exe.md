## Xwizard.exe
* Functions: DLL hijack, Execute
```

xwizard.exe
Xwizard.exe will load a .DLL file located in the same directory (DLL Hijack) named xwizards.dll.

xwizard RunWizard {00000001-0000-0000-0000-0000FEEDACDC}
Xwizard.exe running a custom class that has been added to the registry.
```
   
* Resources:   
  * http://www.hexacorn.com/blog/2017/07/31/the-wizard-of-x-oppa-plugx-style/
  * https://www.youtube.com/watch?v=LwDHX7DVHWU
  * https://gist.github.com/NickTyrer/0598b60112eaafe6d07789f7964290d5
   
* Full path:   
  * c:\windows\system32\xwizard.exe
  * c:\windows\sysWOW32\xwizard.exe
   
* Notes: Thanks to Adam - @Hexacorn, Nick Tyrer - @nicktyrer  
   
