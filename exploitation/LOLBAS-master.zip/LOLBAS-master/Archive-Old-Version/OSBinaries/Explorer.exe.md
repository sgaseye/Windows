## Explorer.exe
* Functions: Execute
```

explorer.exe calc.exe
Executes calc.exe as a subprocess of explorer.exe.
```
   
* Resources:   
  * https://twitter.com/bohops/status/986984122563391488
   
* Full path:   
  * c:\windows\explorer.exe
  * c:\windows\sysWOW64\explorer.exe
   
* Notes: Thanks to Jimmy - @bohops  
   
