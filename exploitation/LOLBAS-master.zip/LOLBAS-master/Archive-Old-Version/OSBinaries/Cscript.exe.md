## Cscript.exe
* Functions: Execute, Read ADS
```

cscript c:\ads\file.txt:script.vbs
Use cscript.exe to exectute a Visual Basic script stored in an Alternate Data Stream (ADS).
```
   
* Resources:   
  * https://gist.github.com/api0cradle/cdd2d0d0ec9abb686f0e89306e277b8f
  * https://oddvar.moe/2018/01/14/putting-data-in-alternate-data-streams-and-how-to-execute-it/
   
* Full path:   
  * c:\windows\system32\cscript.exe
  * c:\windows\sysWOW64\cscript.exe
   
* Notes: Thanks to Oddvar Moe - @oddvarmoe  
   