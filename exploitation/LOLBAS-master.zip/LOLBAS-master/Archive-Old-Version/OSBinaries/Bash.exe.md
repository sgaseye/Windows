## Bash.exe
* Functions: Execute
```

bash.exe -c calc.exe
Execute calc.exe.
```
   
* Resources:   
  * 
   
* Full path:   
  * ?
   
* Notes: Thanks to ?  
   
