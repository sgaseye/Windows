## Zipfldr.dll
* Functions: Execute
```

rundll32.exe zipfldr.dll,RouteTheCall calc.exe
Launch an executable payload by calling RouteTheCall.

rundll32.exe zipfldr.dll,RouteTheCall file://^C^:^/^W^i^n^d^o^w^s^/^s^y^s^t^e^m^3^2^/^c^a^l^c^.^e^x^e
Launch an executable payload by calling RouteTheCall.
```
   
* Resources:   
  * https://twitter.com/moriarty_meng/status/977848311603380224
  * https://twitter.com/bohops/status/997896811904929792
   
* Full path:   
  * c:\windows\system32\zipfldr.dll
  * c:\windows\sysWOW64\zipfldr.dll
   
* Notes: Thanks to Moriarty - @moriarty_meng (Execute), r0lan - @yeyint_mth (Obfuscation)  
   
