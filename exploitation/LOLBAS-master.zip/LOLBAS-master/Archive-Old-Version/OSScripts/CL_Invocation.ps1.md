## CL_Invocation.ps1
* Functions: Execute
```

. C:\\Windows\\diagnostics\\system\\AERO\\CL_Invocation.ps1   \nSyncInvoke <executable> [args]
Import the PowerShell Diagnostic CL_Invocation script and call SyncInvoke to launch an executable.
```
   
* Resources:   
  * https://bohops.com/2018/01/07/executing-commands-and-bypassing-applocker-with-powershell-diagnostic-scripts/
  * https://twitter.com/bohops/status/948548812561436672
  * https://twitter.com/pabraeken/status/995107879345704961
   
* Full path:   
  * C:\Windows\diagnostics\system\AERO\CL_Invocation.ps1
  * C:\Windows\diagnostics\system\Audio\CL_Invocation.ps1
  * C:\Windows\diagnostics\system\WindowsUpdate\CL_Invocation.ps1
   
* Notes: Thanks to Jimmy - @bohops (Execute), Pierre-Alexandre Braeken - @pabraeken (Audio + WindowsUpdate Paths)  
   
