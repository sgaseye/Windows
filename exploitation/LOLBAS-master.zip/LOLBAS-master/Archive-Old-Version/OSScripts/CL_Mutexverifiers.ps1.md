## CL_Mutexverifiers.ps1
* Functions: Execute
```

. C:\Windows\diagnostics\system\AERO\CL_Mutexverifiers.ps1   
runAfterCancelProcess calc.ps1
Import the PowerShell Diagnostic CL_Mutexverifiers script and call runAfterCancelProcess to launch an executable.
```
   
* Resources:   
  * https://twitter.com/pabraeken/status/995111125447577600
   
* Full path:   
  * C:\Windows\diagnostics\system\WindowsUpdate\CL_Mutexverifiers.ps1
  * C:\Windows\diagnostics\system\Audio\CL_Mutexverifiers.ps1
  * C:\Windows\diagnostics\system\WindowsUpdate\CL_Mutexverifiers.ps1
   
* Notes: Thanks to Pierre-Alexandre Braeken - @pabraeken (Audio + WindowsUpdate)  
   
