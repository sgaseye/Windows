## te.exe
* Functions: Execute
```

te.exe bypass.wsc
Run COM Scriptlets (e.g. VBScript) by calling a Windows Script Component (WSC) file.
```
   
* Resources:   
  * https://twitter.com/gn3mes1s/status/927680266390384640?lang=bg
   
* Full path:   
  * 
   
* Notes: Thanks to Giuseppe N3mes1s - @gN3mes1s  
   
