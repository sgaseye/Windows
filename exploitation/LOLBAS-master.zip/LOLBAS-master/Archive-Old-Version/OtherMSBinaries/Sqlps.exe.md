## Sqlps.exe
* Functions: Execute, evade logging
```

Sqlps.exe -noprofile
Drop into a SQL Server PowerShell console without Module and ScriptBlock Logging.
```
   
* Resources:   
  * https://twitter.com/bryon_/status/975835709587075072
   
* Full path:   
  * C:\Program files (x86\Microsoft SQL Server\100\Tools\Binn\sqlps.exe
   
* Notes: Thanks to Bryon - @bryon_  
   
