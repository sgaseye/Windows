## csi.exe
* Functions: Execute
```

csi.exe file
Use csi.exe to run unsigned C# code.
```
   
* Resources:   
  * https://twitter.com/subTee/status/781208810723549188
  * https://enigma0x3.net/2016/11/17/bypassing-application-whitelisting-by-using-dnx-exe/
   
* Full path:   
  * c:\Program Files (x86)\Microsoft Visual Studio\2017\Community\MSBuild\15.0\Bin\Roslyn\csi.exe
  * c:\Program Files (x86)\Microsoft Web Tools\Packages\Microsoft.Net.Compilers.X.Y.Z\tools\csi.exe
   
* Notes: Thanks to Casey Smith - @subtee  
   
