## dnx.exe
* Functions: Execute
```

dnx.exe consoleapp
Execute C# code located in the consoleapp folder via 'Program.cs' and 'Project.json' (Note - Requires dependencies)
```
   
* Resources:   
  * https://enigma0x3.net/2016/11/17/bypassing-application-whitelisting-by-using-dnx-exe/
   
* Full path:   
  * N/A
   
* Notes: Thanks to Matt Nelson - @enigma0x3  
   
