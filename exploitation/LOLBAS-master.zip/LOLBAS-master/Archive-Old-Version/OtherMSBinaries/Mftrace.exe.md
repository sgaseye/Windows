## Mftrace.exe
* Functions: Execute
```

Mftrace.exe cmd.exe
Launch cmd.exe as a subprocess of Mftrace.exe.

Mftrace.exe powershell.exe
Launch cmd.exe as a subprocess of Mftrace.exe.
```
   
* Resources:   
  * https://twitter.com/0rbz_/status/988911181422186496 (Currently not accessible)
   
* Full path:   
  * C:\Program Files (x86)\Windows Kits\10\bin\10.0.16299.0\x86
  * C:\Program Files (x86)\Windows Kits\10\bin\10.0.16299.0\x64
  * C:\Program Files (x86)\Windows Kits\10\bin\x86
  * C:\Program Files (x86)\Windows Kits\10\bin\x64
   
* Notes: Thanks to fabrizio - @0rbz_  
   
