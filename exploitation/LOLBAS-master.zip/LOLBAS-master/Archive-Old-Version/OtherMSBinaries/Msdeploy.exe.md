## Msdeploy.exe
* Functions: Execute
```

msdeploy.exe -verb:sync -source:RunCommand -dest:runCommand="c:\temp\calc.bat"
Launch calc.bat via msdeploy.exe.
```
   
* Resources:   
  * https://twitter.com/pabraeken/status/995837734379032576
   
* Full path:   
  * C:\Program Files (x86)\IIS\Microsoft Web Deploy V3\msdeploy.exe
   
* Notes: Thanks to Pierre-Alexandre Braeken - @pabraeken  
   
