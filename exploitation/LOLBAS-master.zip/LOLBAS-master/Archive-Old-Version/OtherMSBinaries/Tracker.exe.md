## Tracker.exe
* Functions: Execute
```

Tracker.exe /d .\calc.dll /c C:\Windows\write.exe
Use tracker.exe to proxy execution of an arbitrary DLL into another process. Since tracker.exe is also signed it can be used to bypass application whitelisting solutions.
```
   
* Resources:   
  * https://twitter.com/subTee/status/793151392185589760
  * https://attack.mitre.org/wiki/Execution
   
* Full path:   
  * 
   
* Notes: Thanks to Casey Smith - @subTee  
   
