## winword.exe
* Functions: Execute
```

winword.exe /l dllfile.dll
Launch DLL payload.
```
   
* Resources:   
  * https://twitter.com/vysecurity/status/884755482707210241
  * https://twitter.com/Hexacorn/status/885258886428725250
   
* Full path:   
  * c:\Program Files (x86)\Microsoft Office\root\Office16\WINWORD.EXE
   
* Notes: Thanks to Vincent Yiu - @@vysecurity (Cmd), Adam - @Hexacorn (Internals)  
   
