## vsjitdebugger.exe
* Functions: Execute
```

Vsjitdebugger.exe calc.exe
Executes calc.exe as a subprocess of Vsjitdebugger.exe.
```
   
* Resources:   
  * https://twitter.com/pabraeken/status/990758590020452353
   
* Full path:   
  * c:\windows\system32\vsjitdebugger.exe
   
* Notes: Thanks to Pierre-Alexandre Braeken - @pabraeken  
   
