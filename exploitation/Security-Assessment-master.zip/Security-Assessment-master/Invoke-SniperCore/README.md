Automated recon scanner made for Kali Linux with PowerShell Core

![image1](https://github.com/cube0x0/Security-Assessment/blob/master/Invoke-SniperCore/flow.png)


Want to contribute? 
Make a pull request with additional recon or open a issue with the following information. 
* Link to script 
* Port/Service 

