﻿namespace SSH
{
    public enum PoshSessionType
    {
        SFTP,
        SSH,
        SCP
    }
}
