---
external help file: Posh-SSH-help.xml
Module Name: Posh-SSH
online version:
schema: 2.0.0
---

# Convert-SSHRegistryToJSonKnownHost

## SYNOPSIS
Convert windows registry key storage to Json

## SYNTAX

```
Convert-SSHRegistryToJSonKnownHost
```

## DESCRIPTION
Convert windows registry key storage to Json
It is windows-only compatibility cmdlet

## EXAMPLES

### Example 1
```powershell
PS C:\> {{ Add example code here }}
```

{{ Add example description here }}

## PARAMETERS

## INPUTS

## OUTPUTS

## NOTES

## RELATED LINKS
