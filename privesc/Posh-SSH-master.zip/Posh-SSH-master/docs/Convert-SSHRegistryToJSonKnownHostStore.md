---
external help file: Posh-SSH-help.xml
Module Name: Posh-SSH
online version:
schema: 2.0.0
---

# Convert-SSHRegistryToJSonKnownHostStore

## SYNOPSIS
Convert windows registry key storage to JSon

## SYNTAX

```
Convert-SSHRegistryToJSonKnownHostStore
```

## DESCRIPTION
Convert windows registry key storage to JSon
It is windows-only compatibility cmdlet

## EXAMPLES

### Example 1
```powershell
PS C:\> {{ Add example code here }}
```

{{ Add example description here }}

## PARAMETERS

## INPUTS

## OUTPUTS

## NOTES

## RELATED LINKS
